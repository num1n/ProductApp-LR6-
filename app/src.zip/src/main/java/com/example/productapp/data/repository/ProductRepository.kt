package com.example.productapp.data.repository

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.example.productapp.data.network.ApiService
import com.example.productapp.data.paging.ProductsPagingSource
import com.example.productapp.domain.model.Product
import kotlinx.coroutines.flow.Flow

class ProductRepository(private val api: ApiService) {

    fun getPagedProducts(query: String? = null): Flow<PagingData<Product>> {
        return Pager(
            config = PagingConfig(pageSize = 10, prefetchDistance = 2),
            pagingSourceFactory = { ProductsPagingSource(api, query) }
        ).flow
    }
}