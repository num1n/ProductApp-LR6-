package com.example.productapp.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.productapp.data.network.NetworkModule
import com.example.productapp.data.repository.ProductRepository
import com.example.productapp.domain.model.Product
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*

class ProductViewModel : ViewModel() {

    private val repository = ProductRepository(NetworkModule.api)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val pagedProducts: Flow<PagingData<Product>> = _searchQuery
        .debounce(300)
        .flatMapLatest { query ->
            repository.getPagedProducts(query.ifBlank { null })
        }
        .cachedIn(viewModelScope)

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }
}